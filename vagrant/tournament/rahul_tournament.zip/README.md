# Tournament Project

## Dependencies
Please ensure that you have Python 2.7+ and PostgreSQL installed on your machine.

## How to Run
Please run the following commands:

`psql`

'\i tournament.sql'

`\quit`

To run the tests on the program, now run:

`python tournament_test.py`